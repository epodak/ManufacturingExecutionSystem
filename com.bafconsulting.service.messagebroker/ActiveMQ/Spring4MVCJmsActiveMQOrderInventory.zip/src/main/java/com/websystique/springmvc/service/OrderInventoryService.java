package com.websystique.springmvc.service;

import com.websystique.springmvc.model.Order;

public interface OrderInventoryService {

	public void processOrder(Order order);
	
}
